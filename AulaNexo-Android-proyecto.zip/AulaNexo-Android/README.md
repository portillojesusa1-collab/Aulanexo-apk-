# AulaNexo Android — proyecto base

Este proyecto empaqueta la aplicación React existente dentro de un contenedor Android mediante Capacitor. El objetivo es instalarla como APK directamente, sin publicarla en Play Store.

## Requisitos para generar el APK
- Node.js LTS y npm
- Android Studio actualizado
- Android SDK instalado desde Android Studio
- JDK compatible con la versión de Android Gradle Plugin que instale Capacitor

## Generación del proyecto Android
En una terminal, dentro de esta carpeta:

```bash
npm install
npm run build
npm run android:add
npx cap sync android
npx cap open android
```

Android Studio abrirá el proyecto. Para probarlo, conecta el teléfono con depuración USB activada o usa un emulador. Para crear un APK instalable, usa **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Para compartir una versión estable, crea un APK firmado desde **Build > Generate Signed Bundle / APK > APK** y conserva de forma privada la clave de firma.

## Importante sobre esta entrega
- El `App.tsx` original se conserva y se ha colocado dentro de un proyecto Vite + React + Capacitor.
- Se han añadido los tipos mínimos de persistencia que el archivo necesita para compilar; no se han inventado pantallas para materias, exámenes o tarjetas que no venían en los archivos originales.
- Esta base todavía necesita ejecutar `npm install` y generar la carpeta Android en un equipo con Android Studio/SDK. Este entorno no tiene Android SDK ni Gradle instalados, por lo que no es posible afirmar que aquí se haya generado un APK.
- Los datos continúan siendo locales en cada dispositivo. No existe aún sincronización, inicio de sesión ni comunidad multiusuario.

## Comunidad: siguiente fase recomendada
Para que todos los estudiantes compartan grupos, apuntes y recursos, recomiendo integrar Supabase (autenticación, base de datos y almacenamiento) con reglas de seguridad por usuario/grupo. No se deben guardar claves privadas dentro de la app. Primero conviene lanzar la versión personal y probarla; después añadir comunidad con moderación, reportes y controles de privacidad.

## Distribución sin tienda
Puedes compartir el APK firmado mediante una web sencilla o un enlace privado. Android mostrará una advertencia al instalar aplicaciones descargadas fuera de Play Store; los usuarios deben descargarlo solo desde una fuente confiable y autorizar la instalación para ese archivo. Publicar el APK en Google Drive o GitHub Releases no lo convierte en una app de Play Store y no exige pagar una cuota de publicación.
