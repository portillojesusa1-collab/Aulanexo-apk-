import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  LayoutDashboard,
  CheckSquare,
  CalendarClock,
  BookOpenCheck,
  Timer,
  Settings as SettingsIcon,
  Plus,
  Edit3,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Play,
  Pause,
  RotateCcw,
  Download,
  Upload,
  FlaskConical,
  Sparkles,
  BatteryCharging,
  Calendar,
  X,
  Save,
  ShieldAlert,
  ChevronRight,
  ChevronDown,
  Filter,
  Search,
  Moon,
  Sun,
  FileText,
  Flame,
  Star,
  Menu,
  Command as CommandIcon,
  EyeOff,
  Hash,
  GraduationCap,
  AlarmClock,
  Layers,
  MapPin,
  RefreshCw,
  MoreHorizontal,
} from 'lucide-react';
import type { Subject, ScheduleBlock, GradeItem, Exam, FlashcardDeck, Flashcard } from './studentTypes';

/* ============================================================================
   1. TIPOS Y MODELOS DE DATOS
   ============================================================================ */

export type TaskType = 'Estudio' | 'Personal' | 'Trabajo';
export type Priority = 1 | 2 | 3;
export type EnergyLevel = 'Baja' | 'Media' | 'Alta';
export type TabId = 'hoy' | 'tareas' | 'plan' | 'materias' | 'examenes' | 'flashcards' | 'notas' | 'habitos' | 'revision' | 'enfoque' | 'ajustes';
export type Theme = 'light' | 'dark';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export interface Task {
  id: string;
  title: string;
  type: TaskType;
  subjectId: string | null;
  deadline: string;
  minutes: number;
  priority: Priority;
  energy: EnergyLevel;
  notes: string;
  tags: string[];
  done: boolean;
  created: string;
}

export interface Settings {
  hoursPerDay: number;
  theme: Theme;
  aiDecompositionEnabled: boolean;
}

export interface WeeklyReview {
  id: string;
  date: string;
  avance: string;
  atraso: string;
  eliminar: string;
  prioridades: string;
}

export interface Block {
  id: string;
  type: 'text' | 'heading' | 'todo' | 'bullet';
  content: string;
  checked?: boolean;
}

export interface PageNote {
  id: string;
  title: string;
  icon: string;
  blocks: Block[];
  favorite: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Habit {
  id: string;
  name: string;
  color: string;
  checks: Record<string, boolean>;
  createdAt: string;
}

export interface BlocklistItem {
  id: string;
  name: string;
}

export interface FocusSession {
  id: string;
  date: string;
  taskTitle: string;
  plannedMinutes: number;
  interruptions: number;
  completed: boolean;
}

export interface PlanBlock {
  taskId: string;
  title: string;
  minutes: number;
  priority: Priority;
  deadline: string;
  type: TaskType;
}

export interface RiskItem {
  task: Task;
  reason: string;
}

export interface PlanResult {
  plan: Record<string, PlanBlock[]>;
  risk: RiskItem[];
  available7: number;
  required7: number;
  isOverloaded: boolean;
}

export interface TestCaseResult {
  name: string;
  passed: boolean;
  details: string;
}

/* ============================================================================
   2. TEMA — tokens tipo "papel + tinta", distinto del look SaaS genérico
   ============================================================================ */

const THEME_TOKENS: Record<Theme, Record<string, string>> = {
  light: {
    bg: '#FAF9F6',
    sidebar: '#F2F0EB',
    surface: '#FFFFFF',
    border: '#E4E1D8',
    text: '#1F1B16',
    textMuted: '#847F74',
    accent: '#2F6F4E',
    accentSoft: '#E3EFE8',
    warn: '#B8752E',
    warnSoft: '#F6E9D8',
    danger: '#A3372C',
    dangerSoft: '#F6E0DC',
  },
  dark: {
    bg: '#15130F',
    sidebar: '#1B1915',
    surface: '#201E19',
    border: '#332F27',
    text: '#EDEAE1',
    textMuted: '#9C9589',
    accent: '#5FBE8D',
    accentSoft: '#213226',
    warn: '#D99A52',
    warnSoft: '#2E2316',
    danger: '#DB7C6E',
    dangerSoft: '#2E1917',
  },
};

function useTheme(theme: Theme) {
  return useMemo(() => THEME_TOKENS[theme], [theme]);
}

/* ============================================================================
   3. UTILIDADES DE FECHAS Y AUDIO
   ============================================================================ */

function fmtDate(d: Date): string {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function todayStr(): string {
  return fmtDate(new Date());
}
function parseDate(s: string): Date {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
}
function addDays(date: Date, n: number): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + n);
  return d;
}
function humanDate(s: string): string {
  const today = todayStr();
  if (s === today) return 'Hoy';
  const tomorrow = fmtDate(addDays(parseDate(today), 1));
  if (s === tomorrow) return 'Mañana';
  const d = parseDate(s);
  const formatted = d.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'short' });
  return formatted.charAt(0).toUpperCase() + formatted.slice(1);
}
function last14Days(): string[] {
  const out: string[] = [];
  for (let i = 13; i >= 0; i--) out.push(fmtDate(addDays(new Date(), -i)));
  return out;
}
function uid(): string {
  return `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function playCompletionChime() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioCtx();
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.14);
      gain.gain.setValueAtTime(0.15, ctx.currentTime + idx * 0.14);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.14 + 0.5);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + idx * 0.14);
      osc.stop(ctx.currentTime + idx * 0.14 + 0.52);
    });
  } catch {
    /* silencioso si el navegador bloquea AudioContext */
  }
}

/* ============================================================================
   4. PERSISTENCIA — IndexedDB genérica con fallback a localStorage
   ============================================================================ */

const DB_NAME = 'centro_mando_personal_db_v2';
const DB_VERSION = 1;
const STORES = [
  'tasks', 'reviews', 'settings', 'pages', 'habits', 'blocklist', 'focusSessions',
  'subjects', 'scheduleBlocks', 'grades', 'exams', 'flashcardDecks', 'flashcards',
] as const;
type StoreName = (typeof STORES)[number];

class StorageEngine {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private openDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;
    this.dbPromise = new Promise((resolve, reject) => {
      if (typeof indexedDB === 'undefined') {
        reject(new Error('IndexedDB no disponible'));
        return;
      }
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        for (const name of STORES) {
          if (!db.objectStoreNames.contains(name)) {
            if (name === 'settings') db.createObjectStore(name);
            else db.createObjectStore(name, { keyPath: 'id' });
          }
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return this.dbPromise;
  }

  async getAll<T>(store: StoreName): Promise<T[]> {
    try {
      const db = await this.openDB();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(store, 'readonly');
        const req = tx.objectStore(store).getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
      });
    } catch {
      return JSON.parse(localStorage.getItem(`cm_fallback_${store}`) || '[]');
    }
  }

  async put<T extends { id: string }>(store: StoreName, item: T): Promise<void> {
    try {
      const db = await this.openDB();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(store, 'readwrite');
        tx.objectStore(store).put(item);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    } catch {
      const all = await this.getAll<T>(store);
      const idx = all.findIndex((t) => t.id === item.id);
      if (idx >= 0) all[idx] = item;
      else all.push(item);
      localStorage.setItem(`cm_fallback_${store}`, JSON.stringify(all));
    }
  }

  async remove(store: StoreName, id: string): Promise<void> {
    try {
      const db = await this.openDB();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(store, 'readwrite');
        tx.objectStore(store).delete(id);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    } catch {
      const all = (await this.getAll<{ id: string }>(store)).filter((t) => t.id !== id);
      localStorage.setItem(`cm_fallback_${store}`, JSON.stringify(all));
    }
  }

  async getSettings(): Promise<Settings> {
    const fallback: Settings = { hoursPerDay: 3, theme: 'light', aiDecompositionEnabled: false };
    try {
      const db = await this.openDB();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction('settings', 'readonly');
        const req = tx.objectStore('settings').get('user_settings');
        req.onsuccess = () => resolve({ ...fallback, ...(req.result || {}) });
        req.onerror = () => reject(req.error);
      });
    } catch {
      return { ...fallback, ...JSON.parse(localStorage.getItem('cm_fallback_settings_obj') || '{}') };
    }
  }

  async saveSettings(settings: Settings): Promise<void> {
    try {
      const db = await this.openDB();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction('settings', 'readwrite');
        tx.objectStore('settings').put(settings, 'user_settings');
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    } catch {
      localStorage.setItem('cm_fallback_settings_obj', JSON.stringify(settings));
    }
  }

  async exportJSON(): Promise<string> {
    const [tasks, reviews, settings, pages, habits, blocklist, focusSessions, subjects, scheduleBlocks, grades, exams, flashcardDecks, flashcards] = await Promise.all([
      this.getAll<Task>('tasks'),
      this.getAll<WeeklyReview>('reviews'),
      this.getSettings(),
      this.getAll<PageNote>('pages'),
      this.getAll<Habit>('habits'),
      this.getAll<BlocklistItem>('blocklist'),
      this.getAll<FocusSession>('focusSessions'),
      this.getAll<Subject>('subjects'),
      this.getAll<ScheduleBlock>('scheduleBlocks'),
      this.getAll<GradeItem>('grades'),
      this.getAll<Exam>('exams'),
      this.getAll<FlashcardDeck>('flashcardDecks'),
      this.getAll<Flashcard>('flashcards'),
    ]);
    return JSON.stringify({ version: '3.0', exportedAt: new Date().toISOString(), settings, tasks, reviews, pages, habits, blocklist, focusSessions, subjects, scheduleBlocks, grades, exams, flashcardDecks, flashcards }, null, 2);
  }

  async importJSON(raw: string): Promise<void> {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') throw new Error('Formato JSON inválido');
    const map: [StoreName, unknown][] = [
      ['tasks', parsed.tasks],
      ['reviews', parsed.reviews],
      ['pages', parsed.pages],
      ['habits', parsed.habits],
      ['blocklist', parsed.blocklist],
      ['focusSessions', parsed.focusSessions],
      ['subjects', parsed.subjects],
      ['scheduleBlocks', parsed.scheduleBlocks],
      ['grades', parsed.grades],
      ['exams', parsed.exams],
      ['flashcardDecks', parsed.flashcardDecks],
      ['flashcards', parsed.flashcards],
    ];
    for (const [store, arr] of map) {
      if (Array.isArray(arr)) {
        for (const item of arr) {
          if (item && item.id) await this.put(store, item as { id: string });
        }
      }
    }
    if (parsed.settings) await this.saveSettings({ hoursPerDay: 3, theme: 'light', aiDecompositionEnabled: false, ...parsed.settings });
  }

  async clearAll(): Promise<void> {
    try {
      const db = await this.openDB();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(STORES as unknown as string[], 'readwrite');
        for (const s of STORES) tx.objectStore(s).clear();
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    } catch {
      for (const s of STORES) localStorage.removeItem(`cm_fallback_${s}`);
      localStorage.removeItem('cm_fallback_settings_obj');
    }
  }
}

const storage = new StorageEngine();

/* ============================================================================
   5. MOTOR DE PLANIFICACIÓN INVERSA (idéntico al original, intacto)
   ============================================================================ */

export function computePlan(tasks: Task[], hoursPerDay: number, referenceDateStr: string): PlanResult {
  const dailyCapacity = Math.max(15, Math.round(Number(hoursPerDay || 3) * 60));
  const today = parseDate(referenceDateStr);
  const plan: Record<string, PlanBlock[]> = {};
  const used: Record<string, number> = {};
  const risk: RiskItem[] = [];

  const pending = tasks.filter((t) => !t.done && t.deadline).sort((a, b) => a.deadline.localeCompare(b.deadline) || b.priority - a.priority);

  for (const t of pending) {
    let remaining = Math.max(5, Number(t.minutes) || 30);
    const deadline = parseDate(t.deadline);
    if (deadline < today) {
      risk.push({ task: t, reason: 'Fecha límite vencida' });
      continue;
    }
    let cursor = new Date(deadline);
    let guard = 0;
    while (remaining > 0 && cursor >= today && guard < 180) {
      const ds = fmtDate(cursor);
      const cap = dailyCapacity - (used[ds] || 0);
      if (cap > 0) {
        const alloc = Math.min(remaining, cap);
        used[ds] = (used[ds] || 0) + alloc;
        if (!plan[ds]) plan[ds] = [];
        plan[ds].push({ taskId: t.id, title: t.title, minutes: alloc, priority: t.priority, deadline: t.deadline, type: t.type });
        remaining -= alloc;
      }
      cursor = addDays(cursor, -1);
      guard++;
    }
    if (remaining > 0) risk.push({ task: t, reason: `Faltan ${remaining} min por ubicar antes del ${t.deadline}` });
  }

  const available7 = dailyCapacity * 7;
  const limit7 = addDays(today, 6);
  const required7 = tasks
    .filter((t) => !t.done && t.deadline && parseDate(t.deadline) >= today && parseDate(t.deadline) <= limit7)
    .reduce((sum, t) => sum + (Number(t.minutes) || 0), 0);

  return { plan, risk, available7, required7, isOverloaded: required7 > available7 };
}

function runPlannerUnitTests(): TestCaseResult[] {
  const TODAY = '2026-11-22';
  const makeTask = (overrides: Partial<Task>): Task => ({
    id: 'test-id', title: 'Tarea Test', type: 'Estudio', subjectId: null, deadline: '2026-11-25', minutes: 60,
    priority: 2, energy: 'Media', notes: '', tags: [], done: false, created: TODAY, ...overrides,
  });
  const results: TestCaseResult[] = [];
  try {
    const res = computePlan([makeTask({ deadline: '2026-11-24', minutes: 90 })], 3, TODAY);
    const passed = res.plan['2026-11-24']?.[0]?.minutes === 90 && !res.plan[TODAY] && res.risk.length === 0;
    results.push({ name: '1. Asignación inversa en fecha límite', passed, details: passed ? 'Asignó 90 min el 2026-11-24.' : 'Falló la ubicación.' });
  } catch (e) { results.push({ name: '1. Asignación inversa en fecha límite', passed: false, details: String(e) }); }
  try {
    const res = computePlan([makeTask({ deadline: '2026-11-24', minutes: 240 })], 2, TODAY);
    const passed = res.plan['2026-11-24']?.[0]?.minutes === 120 && res.plan['2026-11-23']?.[0]?.minutes === 120 && res.risk.length === 0;
    results.push({ name: '2. División retroactiva de bloques largos', passed, details: passed ? 'Dividió 240 min en dos días.' : 'No dividió correctamente.' });
  } catch (e) { results.push({ name: '2. División retroactiva de bloques largos', passed: false, details: String(e) }); }
  try {
    const res = computePlan([makeTask({ deadline: '2026-11-20', minutes: 45 })], 3, TODAY);
    const passed = res.risk.length === 1 && res.risk[0].reason === 'Fecha límite vencida';
    results.push({ name: '3. Detección de tareas vencidas', passed, details: passed ? 'Detectó la tarea vencida.' : 'No marcó la tarea vencida.' });
  } catch (e) { results.push({ name: '3. Detección de tareas vencidas', passed: false, details: String(e) }); }
  try {
    const res = computePlan([makeTask({ id: '1', deadline: '2026-11-25', minutes: 700 }), makeTask({ id: '2', deadline: '2026-11-26', minutes: 700 })], 3, TODAY);
    const passed = res.isOverloaded && res.required7 === 1400 && res.available7 === 1260;
    results.push({ name: '4. Alerta de sobrecarga semanal', passed, details: passed ? 'Detectó sobrecarga.' : 'No calculó el umbral.' });
  } catch (e) { results.push({ name: '4. Alerta de sobrecarga semanal', passed: false, details: String(e) }); }
  try {
    const res = computePlan([makeTask({ done: true, minutes: 500 })], 3, TODAY);
    const passed = Object.keys(res.plan).length === 0 && res.required7 === 0;
    results.push({ name: '5. Exclusión de tareas completadas', passed, details: passed ? 'Liberó toda la capacidad.' : 'Siguen ocupando tiempo.' });
  } catch (e) { results.push({ name: '5. Exclusión de tareas completadas', passed: false, details: String(e) }); }
  return results;
}

/* ============================================================================
   6. SUBCOMPONENTES COMPARTIDOS
   ============================================================================ */

const AulaNexoMark: React.FC<{ small?: boolean }> = ({ small = false }) => (
  <span className={`aulanexo-mark ${small ? 'aulanexo-mark-small' : ''}`} aria-hidden="true">
    <GraduationCap className="aulanexo-mark-icon" strokeWidth={2.1} />
  </span>
);

const PriorityBadge: React.FC<{ priority: Priority; t: Record<string, string> }> = ({ priority, t }) => {
  const label = priority === 3 ? 'Alta' : priority === 2 ? 'Media' : 'Baja';
  const color = priority === 3 ? t.danger : priority === 2 ? t.warn : t.accent;
  const soft = priority === 3 ? t.dangerSoft : priority === 2 ? t.warnSoft : t.accentSoft;
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border" style={{ color, background: soft, borderColor: color + '55' }}>
      {label}
    </span>
  );
};

/* ============================================================================
   7. FORMULARIO DE TAREAS
   ============================================================================ */

interface TaskFormProps {
  editingTask: Task | null;
  onSave: (task: Task) => void;
  onCancelEdit: () => void;
  t: Record<string, string>;
  subjects: Subject[];
}

const inputClass = (t: Record<string, string>) =>
  `w-full rounded-md px-3 py-2 text-sm outline-none transition-colors border`;

const TaskForm: React.FC<TaskFormProps> = ({ editingTask, onSave, onCancelEdit, t, subjects }) => {
  const [title, setTitle] = useState('');
  const [type, setType] = useState<TaskType>('Estudio');
  const [subjectId, setSubjectId] = useState<string>('');
  const [deadline, setDeadline] = useState(todayStr());
  const [minutes, setMinutes] = useState(30);
  const [priority, setPriority] = useState<Priority>(2);
  const [energy, setEnergy] = useState<EnergyLevel>('Media');
  const [notes, setNotes] = useState('');
  const [tagsInput, setTagsInput] = useState('');

  useEffect(() => {
    if (editingTask) {
      setTitle(editingTask.title);
      setType(editingTask.type);
      setSubjectId(editingTask.subjectId || '');
      setDeadline(editingTask.deadline);
      setMinutes(editingTask.minutes);
      setPriority(editingTask.priority);
      setEnergy(editingTask.energy);
      setNotes(editingTask.notes);
      setTagsInput((editingTask.tags || []).join(', '));
    } else {
      setTitle(''); setType('Estudio'); setSubjectId(''); setDeadline(todayStr()); setMinutes(30);
      setPriority(2); setEnergy('Media'); setNotes(''); setTagsInput('');
    }
  }, [editingTask]);

  const style = { background: t.surface, borderColor: t.border, color: t.text } as React.CSSProperties;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    const tags = tagsInput.split(',').map((s) => s.trim()).filter(Boolean);
    const task: Task = {
      id: editingTask ? editingTask.id : uid(),
      title: title.trim(), type, subjectId: subjectId || null, deadline, minutes: Math.max(5, Number(minutes) || 30),
      priority, energy, notes: notes.trim(), tags,
      done: editingTask ? editingTask.done : false,
      created: editingTask ? editingTask.created : todayStr(),
    };
    onSave(task);
    if (!editingTask) { setTitle(''); setMinutes(30); setPriority(2); setEnergy('Media'); setNotes(''); setTagsInput(''); }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <div>
        <label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>Título de la tarea</label>
        <input type="text" required value={title} onChange={(e) => setTitle(e.target.value)}
          placeholder="Ej: Resumir capítulo 3 o preparar informe"
          className={inputClass(t)} style={style} />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>Tipo</label>
          <select value={type} onChange={(e) => setType(e.target.value as TaskType)} className={inputClass(t)} style={style}>
            <option value="Estudio">Estudio</option><option value="Personal">Personal</option><option value="Trabajo">Trabajo</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>Fecha límite</label>
          <input type="date" required value={deadline} onChange={(e) => setDeadline(e.target.value)} className={inputClass(t)} style={style} />
        </div>
      </div>
      <div>
        <label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>Materia (opcional)</label>
        <select value={subjectId} onChange={(e) => setSubjectId(e.target.value)} className={inputClass(t)} style={style}>
          <option value="">Sin materia</option>
          {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </div>
      <div className="grid grid-cols-3 gap-2.5">
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>Minutos</label>
          <input type="number" min={5} step={5} required value={minutes} onChange={(e) => setMinutes(Number(e.target.value))} className={inputClass(t)} style={style} />
        </div>
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>Prioridad</label>
          <select value={priority} onChange={(e) => setPriority(Number(e.target.value) as Priority)} className={inputClass(t)} style={style}>
            <option value={1}>Baja</option><option value={2}>Media</option><option value={3}>Alta</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>Energía</label>
          <select value={energy} onChange={(e) => setEnergy(e.target.value as EnergyLevel)} className={inputClass(t)} style={style}>
            <option value="Baja">Baja</option><option value="Media">Media</option><option value="Alta">Alta</option>
          </select>
        </div>
      </div>
      <div>
        <label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>Etiquetas (separadas por coma)</label>
        <input type="text" value={tagsInput} onChange={(e) => setTagsInput(e.target.value)} placeholder="tesis, cliente-x, urgente" className={inputClass(t)} style={style} />
      </div>
      <div>
        <label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>Notas</label>
        <textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Detalles, enlaces o criterios de éxito (opcional)" className={inputClass(t) + ' resize-y'} style={style} />
      </div>
      <div className="flex flex-wrap gap-2 pt-1">
        <button type="submit" className="flex-1 inline-flex items-center justify-center gap-2 font-semibold text-sm px-4 py-2.5 rounded-md transition-opacity hover:opacity-90"
          style={{ background: t.accent, color: '#fff' }}>
          {editingTask ? <Save className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {editingTask ? 'Guardar cambios' : 'Añadir tarea'}
        </button>
        {editingTask && (
          <button type="button" onClick={onCancelEdit} className="inline-flex items-center justify-center gap-1.5 text-sm font-medium px-4 py-2.5 rounded-md border"
            style={{ background: t.surface, color: t.text, borderColor: t.border }}>
            <X className="w-4 h-4" />Cancelar
          </button>
        )}
      </div>
    </form>
  );
};

/* ============================================================================
   8. PALETA DE COMANDOS (Cmd/Ctrl + K)
   ============================================================================ */

interface CommandAction { id: string; label: string; hint?: string; onRun: () => void; icon: React.ReactNode }

const CommandPalette: React.FC<{ open: boolean; onClose: () => void; actions: CommandAction[]; t: Record<string, string> }> = ({ open, onClose, actions, t }) => {
  const [q, setQ] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => { if (open) { setQ(''); setTimeout(() => inputRef.current?.focus(), 10); } }, [open]);
  if (!open) return null;
  const filtered = actions.filter((a) => a.label.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-24 px-4" style={{ background: 'rgba(0,0,0,0.4)' }} onClick={onClose}>
      <div className="w-full max-w-lg rounded-xl border shadow-2xl overflow-hidden" style={{ background: t.surface, borderColor: t.border }} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 px-4 py-3 border-b" style={{ borderColor: t.border }}>
          <Search className="w-4 h-4" style={{ color: t.textMuted }} />
          <input ref={inputRef} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar tareas, notas o acciones…"
            className="flex-1 bg-transparent outline-none text-sm" style={{ color: t.text }} />
          <kbd className="text-xs px-1.5 py-0.5 rounded border" style={{ borderColor: t.border, color: t.textMuted }}>Esc</kbd>
        </div>
        <div className="max-h-80 overflow-y-auto py-1.5">
          {filtered.length === 0 ? (
            <p className="px-4 py-6 text-sm text-center" style={{ color: t.textMuted }}>Sin resultados.</p>
          ) : (
            filtered.map((a) => (
              <button key={a.id} onClick={() => { a.onRun(); onClose(); }}
                className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-left hover:opacity-80"
                style={{ color: t.text }}>
                <span style={{ color: t.textMuted }}>{a.icon}</span>
                <span className="flex-1">{a.label}</span>
                {a.hint && <span className="text-xs" style={{ color: t.textMuted }}>{a.hint}</span>}
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

/* ============================================================================
   9. COMPONENTE PRINCIPAL
   ============================================================================ */

export function App() {
  const [activeTab, setActiveTab] = useState<TabId>('hoy');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [reviews, setReviews] = useState<WeeklyReview[]>([]);
  const [pages, setPages] = useState<PageNote[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [blocklist, setBlocklist] = useState<BlocklistItem[]>([]);
  const [focusSessions, setFocusSessions] = useState<FocusSession[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [scheduleBlocks, setScheduleBlocks] = useState<ScheduleBlock[]>([]);
  const [grades, setGrades] = useState<GradeItem[]>([]);
  const [exams, setExams] = useState<Exam[]>([]);
  const [flashcardDecks, setFlashcardDecks] = useState<FlashcardDeck[]>([]);
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [settings, setSettings] = useState<Settings>({ hoursPerDay: 3, theme: 'light', aiDecompositionEnabled: false });
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);

  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'done'>('all');
  const [filterType, setFilterType] = useState<'all' | TaskType>('all');

  const [revAvance, setRevAvance] = useState('');
  const [revAtraso, setRevAtraso] = useState('');
  const [revEliminar, setRevEliminar] = useState('');
  const [revPrioridades, setRevPrioridades] = useState('');

  const [focusTaskId, setFocusTaskId] = useState<string>('');
  const [pomodoroMinutes, setPomodoroMinutes] = useState<number>(25);
  const [secondsLeft, setSecondsLeft] = useState<number>(25 * 60);
  const [timerRunning, setTimerRunning] = useState<boolean>(false);
  const [timerFinishedBanner, setTimerFinishedBanner] = useState<boolean>(false);
  const [interruptions, setInterruptions] = useState<number>(0);
  const [newBlockItem, setNewBlockItem] = useState('');

  const [selectedPageId, setSelectedPageId] = useState<string | null>(null);
  const [newPageTitle, setNewPageTitle] = useState('');
  const [newHabitName, setNewHabitName] = useState('');

  const [hoursInput, setHoursInput] = useState<number>(3);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'ok' | 'warn' | 'bad' } | null>(null);
  const [confirmClearModal, setConfirmClearModal] = useState<boolean>(false);
  const [testResults, setTestResults] = useState<TestCaseResult[] | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const t = useTheme(settings.theme);

  const showToast = (text: string, type: 'ok' | 'warn' | 'bad' = 'ok') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage((prev) => (prev?.text === text ? null : prev)), 3500);
  };

  const reloadAll = useCallback(async () => {
    const [
      loadedTasks, loadedReviews, loadedSettings, loadedPages, loadedHabits, loadedBlocklist, loadedSessions,
      loadedSubjects, loadedScheduleBlocks, loadedGrades, loadedExams, loadedDecks, loadedFlashcards,
    ] = await Promise.all([
      storage.getAll<Task>('tasks'), storage.getAll<WeeklyReview>('reviews'), storage.getSettings(),
      storage.getAll<PageNote>('pages'), storage.getAll<Habit>('habits'), storage.getAll<BlocklistItem>('blocklist'),
      storage.getAll<FocusSession>('focusSessions'),
      storage.getAll<Subject>('subjects'), storage.getAll<ScheduleBlock>('scheduleBlocks'),
      storage.getAll<GradeItem>('grades'), storage.getAll<Exam>('exams'),
      storage.getAll<FlashcardDeck>('flashcardDecks'), storage.getAll<Flashcard>('flashcards'),
    ]);
    setTasks(loadedTasks); setReviews(loadedReviews); setSettings(loadedSettings);
    setPages(loadedPages); setHabits(loadedHabits); setBlocklist(loadedBlocklist); setFocusSessions(loadedSessions);
    setSubjects(loadedSubjects); setScheduleBlocks(loadedScheduleBlocks); setGrades(loadedGrades);
    setExams(loadedExams); setFlashcardDecks(loadedDecks); setFlashcards(loadedFlashcards);
    setHoursInput(loadedSettings.hoursPerDay);
    setLoading(false);
  }, []);

  useEffect(() => { reloadAll(); }, [reloadAll]);

  // PWA: cache the app shell for repeat visits and offline reopening.
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {
        // La app sigue funcionando aunque el hosting no permita service workers.
      });
    }
    const onInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', onInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', onInstallPrompt);
  }, []);

  useEffect(() => {
    const pending = tasks.filter((tk) => !tk.done);
    if (pending.length > 0 && !pending.some((tk) => tk.id === focusTaskId)) setFocusTaskId(pending[0].id);
    else if (pending.length === 0) setFocusTaskId('');
  }, [tasks, focusTaskId]);

  const planResult = useMemo(() => computePlan(tasks, settings.hoursPerDay, todayStr()), [tasks, settings.hoursPerDay]);

  // Temporizador Pomodoro
  useEffect(() => {
    if (!timerRunning) return;
    const interval = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          setTimerRunning(false); setTimerFinishedBanner(true); playCompletionChime();
          const task = tasks.find((tk) => tk.id === focusTaskId);
          const session: FocusSession = { id: uid(), date: todayStr(), taskTitle: task?.title || 'Sin tarea', plannedMinutes: pomodoroMinutes, interruptions, completed: true };
          storage.put('focusSessions', session).then(reloadAll);
          setInterruptions(0);
          return pomodoroMinutes * 60;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timerRunning, pomodoroMinutes]);

  // Detección de distracción: cambiar de pestaña durante una sesión activa.
  // Esto NO bloquea nada (un sitio web no puede impedir que abras otra app u
  // otra pestaña); es un registro honesto de honor para generar conciencia.
  useEffect(() => {
    const onVisibility = () => {
      if (document.hidden && timerRunning) setInterruptions((n) => n + 1);
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => document.removeEventListener('visibilitychange', onVisibility);
  }, [timerRunning]);

  // Atajo de teclado Cmd/Ctrl+K
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPaletteOpen((o) => !o); }
      if (e.key === 'Escape') setPaletteOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const handleInstallApp = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    await installPrompt.userChoice;
    setInstallPrompt(null);
  };

  const handleSaveTask = async (task: Task) => {
    await storage.put('tasks', task);
    const isEdit = Boolean(editingTask);
    setEditingTask(null);
    await reloadAll();
    showToast(isEdit ? 'Tarea actualizada y plan recalculado.' : 'Tarea añadida al plan.');
  };
  const handleToggleTaskDone = async (task: Task) => { await storage.put('tasks', { ...task, done: !task.done }); await reloadAll(); };
  const handleDeleteTask = async (id: string) => {
    await storage.remove('tasks', id);
    if (editingTask?.id === id) setEditingTask(null);
    await reloadAll();
    showToast('Tarea eliminada.', 'warn');
  };
  const handleStartEditTask = (task: Task) => { setEditingTask(task); setActiveTab('hoy'); window.scrollTo({ top: 0, behavior: 'smooth' }); };

  const handleSaveReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!revAvance.trim() || !revPrioridades.trim()) return;
    const review: WeeklyReview = { id: uid(), date: todayStr(), avance: revAvance.trim(), atraso: revAtraso.trim(), eliminar: revEliminar.trim(), prioridades: revPrioridades.trim() };
    await storage.put('reviews', review);
    setRevAvance(''); setRevAtraso(''); setRevEliminar(''); setRevPrioridades('');
    await reloadAll();
    showToast('Revisión semanal guardada.');
  };

  const handleSaveSettings = async (patch: Partial<Settings>) => {
    const next = { ...settings, ...patch };
    await storage.saveSettings(next);
    setSettings(next);
  };

  const handleExportJSON = async () => {
    const json = await storage.exportJSON();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url; link.download = `aulanexo-backup-${todayStr()}.json`; link.click();
    URL.revokeObjectURL(url);
    showToast('Respaldo JSON descargado.');
  };
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try { await storage.importJSON(String(ev.target?.result || '')); await reloadAll(); showToast('Datos restaurados.'); }
      catch { showToast('Error al leer el archivo JSON.', 'bad'); }
      finally { if (fileInputRef.current) fileInputRef.current.value = ''; }
    };
    reader.readAsText(file);
  };
  const handleConfirmClearAll = async () => {
    await storage.clearAll(); setConfirmClearModal(false); setEditingTask(null); await reloadAll();
    showToast('Todos los datos locales han sido eliminados.', 'warn');
  };

  // Notas (páginas estilo Notion)
  const handleCreatePage = async () => {
    if (!newPageTitle.trim()) return;
    const page: PageNote = { id: uid(), title: newPageTitle.trim(), icon: '📄', blocks: [{ id: uid(), type: 'text', content: '' }], favorite: false, createdAt: todayStr(), updatedAt: todayStr() };
    await storage.put('pages', page);
    setNewPageTitle(''); await reloadAll(); setSelectedPageId(page.id);
  };
  const handleUpdatePage = async (page: PageNote) => { await storage.put('pages', { ...page, updatedAt: todayStr() }); await reloadAll(); };
  const handleDeletePage = async (id: string) => { await storage.remove('pages', id); if (selectedPageId === id) setSelectedPageId(null); await reloadAll(); };

  // Hábitos
  const handleCreateHabit = async () => {
    if (!newHabitName.trim()) return;
    const colors = ['#2F6F4E', '#B8752E', '#4C6FBE', '#A3372C', '#7B4FA3'];
    const habit: Habit = { id: uid(), name: newHabitName.trim(), color: colors[habits.length % colors.length], checks: {}, createdAt: todayStr() };
    await storage.put('habits', habit); setNewHabitName(''); await reloadAll();
  };
  const toggleHabitDay = async (habit: Habit, day: string) => {
    const checks = { ...habit.checks, [day]: !habit.checks[day] };
    await storage.put('habits', { ...habit, checks }); await reloadAll();
  };
  const handleDeleteHabit = async (id: string) => { await storage.remove('habits', id); await reloadAll(); };

  // Materias
  const handleSaveSubject = async (subject: Subject) => { await storage.put('subjects', subject); await reloadAll(); };
  const handleDeleteSubject = async (id: string) => {
    await storage.remove('subjects', id);
    // Limpieza en cascada de lo que depende de la materia
    for (const b of scheduleBlocks.filter((x) => x.subjectId === id)) await storage.remove('scheduleBlocks', b.id);
    for (const g of grades.filter((x) => x.subjectId === id)) await storage.remove('grades', g.id);
    for (const ex of exams.filter((x) => x.subjectId === id)) await storage.remove('exams', ex.id);
    await reloadAll();
    showToast('Materia eliminada.', 'warn');
  };
  const handleSaveScheduleBlock = async (block: ScheduleBlock) => { await storage.put('scheduleBlocks', block); await reloadAll(); };
  const handleDeleteScheduleBlock = async (id: string) => { await storage.remove('scheduleBlocks', id); await reloadAll(); };
  const handleSaveGrade = async (grade: GradeItem) => { await storage.put('grades', grade); await reloadAll(); };
  const handleDeleteGrade = async (id: string) => { await storage.remove('grades', id); await reloadAll(); };

  // Exámenes
  const handleSaveExam = async (exam: Exam) => { await storage.put('exams', exam); await reloadAll(); showToast('Examen guardado.'); };
  const handleDeleteExam = async (id: string) => { await storage.remove('exams', id); await reloadAll(); };

  // Flashcards con repetición espaciada
  const handleSaveDeck = async (deck: FlashcardDeck) => { await storage.put('flashcardDecks', deck); await reloadAll(); };
  const handleDeleteDeck = async (id: string) => {
    await storage.remove('flashcardDecks', id);
    for (const c of flashcards.filter((x) => x.deckId === id)) await storage.remove('flashcards', c.id);
    await reloadAll();
  };
  const handleSaveCard = async (card: Flashcard) => { await storage.put('flashcards', card); await reloadAll(); };
  const handleDeleteCard = async (id: string) => { await storage.remove('flashcards', id); await reloadAll(); };

  // Lista de compromiso (enfoque)
  const handleAddBlockItem = async () => {
    if (!newBlockItem.trim()) return;
    await storage.put('blocklist', { id: uid(), name: newBlockItem.trim() });
    setNewBlockItem(''); await reloadAll();
  };
  const handleRemoveBlockItem = async (id: string) => { await storage.remove('blocklist', id); await reloadAll(); };

  const today = todayStr();
  const todayBlocks = planResult.plan[today] || [];
  const todayPlannedMinutes = todayBlocks.reduce((acc, b) => acc + b.minutes, 0);
  const pendingCount = tasks.filter((tk) => !tk.done).length;
  const favoritePages = pages.filter((p) => p.favorite);

  const filteredTasks = useMemo(() => {
    return [...tasks]
      .filter((tk) => {
        if (filterStatus === 'pending' && tk.done) return false;
        if (filterStatus === 'done' && !tk.done) return false;
        if (filterType !== 'all' && tk.type !== filterType) return false;
        return true;
      })
      .sort((a, b) => (a.done !== b.done ? (a.done ? 1 : -1) : (a.deadline || '9999-12-31').localeCompare(b.deadline || '9999-12-31')));
  }, [tasks, filterStatus, filterType]);

  const formattedTimer = `${String(Math.floor(secondsLeft / 60)).padStart(2, '0')}:${String(secondsLeft % 60).padStart(2, '0')}`;
  const selectedPage = pages.find((p) => p.id === selectedPageId) || null;

  const paletteActions: CommandAction[] = useMemo(() => [
    { id: 'nav-hoy', label: 'Ir a Hoy', icon: <LayoutDashboard className="w-4 h-4" />, onRun: () => setActiveTab('hoy') },
    { id: 'nav-tareas', label: 'Ir a Tareas', icon: <CheckSquare className="w-4 h-4" />, onRun: () => setActiveTab('tareas') },
    { id: 'nav-plan', label: 'Ir a Plan', icon: <CalendarClock className="w-4 h-4" />, onRun: () => setActiveTab('plan') },
    { id: 'nav-notas', label: 'Ir a Notas', icon: <FileText className="w-4 h-4" />, onRun: () => setActiveTab('notas') },
    { id: 'nav-habitos', label: 'Ir a Hábitos', icon: <Flame className="w-4 h-4" />, onRun: () => setActiveTab('habitos') },
    { id: 'nav-enfoque', label: 'Ir a Enfoque', icon: <Timer className="w-4 h-4" />, onRun: () => setActiveTab('enfoque') },
    { id: 'theme', label: settings.theme === 'light' ? 'Cambiar a tema oscuro' : 'Cambiar a tema claro', icon: settings.theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />, onRun: () => handleSaveSettings({ theme: settings.theme === 'light' ? 'dark' : 'light' }) },
    ...tasks.filter((tk) => !tk.done).map((tk) => ({ id: `task-${tk.id}`, label: tk.title, hint: 'Tarea', icon: <CheckSquare className="w-4 h-4" />, onRun: () => handleStartEditTask(tk) })),
    ...pages.map((p) => ({ id: `page-${p.id}`, label: p.title, hint: 'Nota', icon: <FileText className="w-4 h-4" />, onRun: () => { setActiveTab('notas'); setSelectedPageId(p.id); } })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
  ], [tasks, pages, settings.theme]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: t.bg, color: t.textMuted }}>
        <div className="flex items-center gap-3 text-sm font-medium"><Sparkles className="w-5 h-5 animate-pulse" style={{ color: t.accent }} />Preparando AulaNexo…</div>
      </div>
    );
  }

  const navItems: { id: TabId; label: string; icon: React.ReactNode }[] = [
    { id: 'hoy', label: 'Hoy', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'tareas', label: `Tareas (${pendingCount})`, icon: <CheckSquare className="w-4 h-4" /> },
    { id: 'plan', label: 'Plan', icon: <CalendarClock className="w-4 h-4" /> },
    { id: 'notas', label: 'Notas', icon: <FileText className="w-4 h-4" /> },
    { id: 'habitos', label: 'Hábitos', icon: <Flame className="w-4 h-4" /> },
    { id: 'revision', label: 'Revisión semanal', icon: <BookOpenCheck className="w-4 h-4" /> },
    { id: 'enfoque', label: 'Enfoque', icon: <Timer className="w-4 h-4" /> },
    { id: 'ajustes', label: 'Ajustes', icon: <SettingsIcon className="w-4 h-4" /> },
  ];
  const mobilePrimaryIds: TabId[] = ['hoy', 'tareas', 'plan', 'enfoque'];

  return (
    <div className="aulanexo-shell min-h-screen flex" style={{ background: t.bg, color: t.text, fontFamily: 'ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif' }}>
      <style>{`
        .aulanexo-mark{width:42px;height:42px;display:inline-flex;align-items:center;justify-content:center;flex:none;border-radius:14px;background:#244B3A;color:#fff;box-shadow:inset 0 0 0 1px rgba(255,255,255,.12)}
        .aulanexo-mark-icon{width:24px;height:24px}
        .aulanexo-mark-small{width:34px;height:34px;border-radius:11px}
        .aulanexo-mark-small .aulanexo-mark-icon{width:20px;height:20px}
        .aulanexo-mobile-brand{display:none}
        .aulanexo-mobile-nav{display:none}
        .aulanexo-more-panel{display:none}
        .aulanexo-shell button{touch-action:manipulation}
        @media(max-width:767px){
          .aulanexo-shell{display:flex;flex-direction:column;min-height:100vh;min-height:100dvh;padding-bottom:calc(72px + env(safe-area-inset-bottom))}
          .aulanexo-sidebar{display:none!important}
          .aulanexo-content{width:100%;min-width:0;min-height:100dvh}
          .aulanexo-header{position:sticky;top:0;z-index:35;padding:10px 14px;background:${t.surface};backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px)}
          .aulanexo-mobile-brand{display:flex;align-items:center;gap:9px;min-width:0}
          .aulanexo-mobile-brand-copy{display:flex;flex-direction:column;line-height:1.15;min-width:0}
          .aulanexo-mobile-brand-copy strong{font-size:14px;letter-spacing:-.02em}
          .aulanexo-mobile-brand-copy span{font-size:11px;color:${t.textMuted};max-width:44vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:3px}
          .aulanexo-desktop-page-label{display:none}
          .aulanexo-main{max-width:100%!important;width:100%!important;padding:16px 13px 24px!important;margin:0!important;overflow-x:hidden}
          .aulanexo-main .rounded-xl{border-radius:16px}
          .aulanexo-main input:not([type=checkbox]),.aulanexo-main select,.aulanexo-main textarea{font-size:16px!important;max-width:100%;}
          .aulanexo-mobile-nav{position:fixed;z-index:45;left:0;right:0;bottom:0;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:2px;padding:7px 8px calc(7px + env(safe-area-inset-bottom));border-top:1px solid ${t.border};background:${t.surface};box-shadow:0 -8px 24px rgba(0,0,0,.07)}
          .aulanexo-mobile-nav button{min-width:0;min-height:48px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;border:0;border-radius:12px;background:transparent;color:${t.textMuted};font-size:10px;font-weight:600;padding:4px 2px}
          .aulanexo-mobile-nav button.active{background:${t.accentSoft};color:${t.accent}}
          .aulanexo-mobile-nav button svg{width:19px;height:19px}
          .aulanexo-more-panel{display:block;position:fixed;z-index:44;left:12px;right:12px;bottom:calc(70px + env(safe-area-inset-bottom));max-height:55vh;overflow-y:auto;padding:9px;border:1px solid ${t.border};border-radius:18px;background:${t.surface};box-shadow:0 16px 50px rgba(0,0,0,.18)}
          .aulanexo-more-panel button{width:100%;min-height:46px;display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:11px;text-align:left;font-size:13px}
          .aulanexo-toast{left:12px!important;right:12px!important;bottom:calc(80px + env(safe-area-inset-bottom))!important;max-width:none!important}
          .aulanexo-task-actions button{min-width:40px;min-height:40px}
          .aulanexo-timer-digits{font-size:clamp(2.6rem,13vw,4rem)!important}
        }
        @media(min-width:768px){.aulanexo-more-panel{display:none!important}}
        @media(prefers-reduced-motion:reduce){.aulanexo-shell *{scroll-behavior:auto!important;animation-duration:.01ms!important;transition-duration:.01ms!important}}
      `}</style>
      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} actions={paletteActions} t={t} />

      {toastMessage && (
        <div className="aulanexo-toast fixed bottom-4 right-4 z-50 max-w-sm">
          <div className="px-4 py-3 rounded-md border shadow-lg text-sm font-medium flex items-center gap-2.5"
            style={{
              background: toastMessage.type === 'bad' ? t.dangerSoft : toastMessage.type === 'warn' ? t.warnSoft : t.accentSoft,
              borderColor: toastMessage.type === 'bad' ? t.danger : toastMessage.type === 'warn' ? t.warn : t.accent,
              color: toastMessage.type === 'bad' ? t.danger : toastMessage.type === 'warn' ? t.warn : t.accent,
            }}>
            {toastMessage.type === 'bad' ? <AlertTriangle className="w-4 h-4 shrink-0" /> : <CheckCircle2 className="w-4 h-4 shrink-0" />}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Barra lateral estilo Notion */}
      {sidebarOpen && (
        <aside className="aulanexo-sidebar w-64 shrink-0 border-r flex flex-col" style={{ background: t.sidebar, borderColor: t.border }}>
          <div className="px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <AulaNexoMark />
              <div>
                <h1 className="text-base font-extrabold tracking-tight">AulaNexo</h1>
                <p className="text-xs" style={{ color: t.textMuted }}>Tu espacio para aprender</p>
              </div>
            </div>
            <button onClick={() => setSidebarOpen(false)} className="p-1.5 rounded hover:opacity-70" style={{ color: t.textMuted }}><Menu className="w-4 h-4" /></button>
          </div>

          <button onClick={() => setPaletteOpen(true)} className="mx-3 mb-3 flex items-center gap-2 px-2.5 py-1.5 rounded-md border text-xs"
            style={{ borderColor: t.border, color: t.textMuted, background: t.surface }}>
            <Search className="w-3.5 h-3.5" /> Buscar… <kbd className="ml-auto flex items-center gap-0.5"><CommandIcon className="w-3 h-3" />K</kbd>
          </button>

          <nav className="flex-1 overflow-y-auto px-2 space-y-0.5">
            {navItems.map((item) => {
              const active = activeTab === item.id;
              return (
                <button key={item.id} onClick={() => setActiveTab(item.id)}
                  className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md text-sm text-left transition-colors"
                  style={{ background: active ? t.accentSoft : 'transparent', color: active ? t.accent : t.text, fontWeight: active ? 600 : 400 }}>
                  {item.icon}{item.label}
                </button>
              );
            })}

            {favoritePages.length > 0 && (
              <div className="pt-3">
                <p className="px-2.5 text-xs font-semibold mb-1" style={{ color: t.textMuted }}>Favoritas</p>
                {favoritePages.map((p) => (
                  <button key={p.id} onClick={() => { setActiveTab('notas'); setSelectedPageId(p.id); }}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md text-sm text-left hover:opacity-80" style={{ color: t.text }}>
                    <span>{p.icon}</span><span className="truncate">{p.title}</span>
                  </button>
                ))}
              </div>
            )}
          </nav>

          <div className="p-3 border-t text-xs" style={{ borderColor: t.border, color: t.textMuted }}>
            {planResult.isOverloaded ? (
              <span className="inline-flex items-center gap-1" style={{ color: t.danger }}><ShieldAlert className="w-3.5 h-3.5" />Sobrecarga próx. 7 días</span>
            ) : (
              <span className="inline-flex items-center gap-1" style={{ color: t.accent }}><CheckCircle2 className="w-3.5 h-3.5" />Carga equilibrada</span>
            )}
          </div>
        </aside>
      )}

      <div className="aulanexo-content flex-1 flex flex-col min-w-0">
        {/* Barra superior */}
        <header className="aulanexo-header flex items-center justify-between px-5 py-3 border-b" style={{ borderColor: t.border }}>
          <div className="flex items-center gap-2 min-w-0">
            {!sidebarOpen && (
              <button onClick={() => setSidebarOpen(true)} className="p-1.5 rounded hover:opacity-70" style={{ color: t.textMuted }} aria-label="Mostrar menú"><Menu className="w-4 h-4" /></button>
            )}
            <div className="aulanexo-mobile-brand">
              <AulaNexoMark small />
              <div className="aulanexo-mobile-brand-copy"><strong>AulaNexo</strong><span>{navItems.find((n) => n.id === activeTab)?.label}</span></div>
            </div>
            <span className="aulanexo-desktop-page-label text-sm" style={{ color: t.textMuted }}>{navItems.find((n) => n.id === activeTab)?.label}</span>
          </div>
          <div className="flex items-center gap-2">
            {installPrompt && <button onClick={handleInstallApp} className="px-3 py-2 rounded-lg text-xs font-semibold" style={{ background: t.accent, color: '#fff' }}>Instalar</button>}
            <button onClick={() => handleSaveSettings({ theme: settings.theme === 'light' ? 'dark' : 'light' })}
              className="p-2 rounded-lg border" style={{ borderColor: t.border, color: t.textMuted }} aria-label="Cambiar tema">
              {settings.theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>
          </div>
        </header>

        <main className="aulanexo-main flex-1 overflow-y-auto px-5 py-6 space-y-5" style={{ maxWidth: 980, width: '100%', margin: '0 auto' }}>
          {/* ============ HOY ============ */}
          {activeTab === 'hoy' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                <div className="lg:col-span-5 rounded-xl border p-4 sm:p-5 space-y-4" style={{ background: t.surface, borderColor: t.border }}>
                  <h2 className="text-base font-bold flex items-center gap-2"><Sparkles className="w-4 h-4" style={{ color: t.accent }} />Resumen de hoy</h2>
                  {planResult.isOverloaded ? (
                    <div className="p-3.5 rounded-md border text-xs sm:text-sm flex items-start gap-2.5" style={{ background: t.dangerSoft, borderColor: t.danger, color: t.danger }}>
                      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                      <div><p className="font-semibold">Sobrecarga detectada (próximos 7 días)</p><p className="mt-0.5">Requieres <strong>{planResult.required7} min</strong> y dispones de <strong>{planResult.available7} min</strong>.</p></div>
                    </div>
                  ) : (
                    <div className="p-3.5 rounded-md border text-xs sm:text-sm flex items-start gap-2.5" style={{ background: t.accentSoft, borderColor: t.accent, color: t.accent }}>
                      <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                      <div><p className="font-semibold">Sin sobrecarga en los próximos 7 días</p><p className="mt-0.5"><strong>{planResult.required7} min</strong> comprometidos de <strong>{planResult.available7} min</strong>.</p></div>
                    </div>
                  )}
                  {planResult.risk.length > 0 && (
                    <div className="p-3 rounded-md border text-xs sm:text-sm flex items-center justify-between gap-2" style={{ background: t.warnSoft, borderColor: t.warn, color: t.warn }}>
                      <span className="inline-flex items-center gap-2"><ShieldAlert className="w-4 h-4 shrink-0" /><strong>{planResult.risk.length} tarea(s) en riesgo</strong></span>
                      <button onClick={() => setActiveTab('plan')} className="text-xs underline font-semibold">Ver plan</button>
                    </div>
                  )}
                  <div className="rounded-md border p-3.5" style={{ borderColor: t.border }}>
                    <div className="flex items-center justify-between text-xs mb-1.5" style={{ color: t.textMuted }}>
                      <span>Carga planificada para hoy</span><span>{todayPlannedMinutes} / {Math.round(settings.hoursPerDay * 60)} min</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full overflow-hidden" style={{ background: t.border }}>
                      <div className="h-full transition-all duration-300" style={{ width: `${Math.min(100, Math.round((todayPlannedMinutes / Math.max(1, settings.hoursPerDay * 60)) * 100))}%`, background: t.accent }} />
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-7 rounded-xl border p-4 sm:p-5" style={{ background: t.surface, borderColor: t.border }}>
                  <div className="flex items-center justify-between mb-3">
                    <h2 className="text-base font-bold flex items-center gap-2">
                      {editingTask ? <><Edit3 className="w-4 h-4" style={{ color: t.warn }} />Editar tarea</> : <><Plus className="w-4 h-4" style={{ color: t.accent }} />Añadir tarea rápida</>}
                    </h2>
                  </div>
                  <TaskForm editingTask={editingTask} onSave={handleSaveTask} onCancelEdit={() => setEditingTask(null)} t={t} subjects={subjects} />
                </div>
              </div>

              <div className="rounded-xl border p-4 sm:p-5" style={{ background: t.surface, borderColor: t.border }}>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-base font-bold flex items-center gap-2"><CalendarClock className="w-4 h-4" style={{ color: t.accent }} />Plan sugerido para hoy ({humanDate(today)})</h2>
                  {todayBlocks.length > 0 && (
                    <button onClick={() => { setFocusTaskId(todayBlocks[0].taskId); setActiveTab('enfoque'); }} className="inline-flex items-center gap-1 text-xs font-semibold" style={{ color: t.accent }}>Iniciar enfoque<ChevronRight className="w-3.5 h-3.5" /></button>
                  )}
                </div>
                {todayBlocks.length === 0 ? (
                  <div className="text-center py-6 rounded-md border border-dashed" style={{ borderColor: t.border }}>
                    <p className="text-sm" style={{ color: t.textMuted }}>No tienes bloques obligatorios asignados para hoy.</p>
                  </div>
                ) : (
                  <div className="divide-y" style={{ borderColor: t.border }}>
                    {todayBlocks.map((block, idx) => (
                      <div key={`${block.taskId}-${idx}`} className="py-3 flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-3">
                          <span className="px-2.5 py-1 rounded-md border font-bold text-xs" style={{ background: t.accentSoft, borderColor: t.accent, color: t.accent }}>{block.minutes} min</span>
                          <div><p className="text-sm font-medium">{block.title}</p><p className="text-xs" style={{ color: t.textMuted }}>{block.type} · Límite: {block.deadline}</p></div>
                        </div>
                        <PriorityBadge priority={block.priority} t={t} />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ============ TAREAS ============ */}
          {activeTab === 'tareas' && (
            <div className="rounded-xl border p-4 sm:p-5 space-y-4" style={{ background: t.surface, borderColor: t.border }}>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div><h2 className="text-base font-bold">Todas las tareas</h2><p className="text-xs" style={{ color: t.textMuted }}>{pendingCount} pendiente(s) · {tasks.length - pendingCount} completada(s)</p></div>
                <div className="flex flex-wrap items-center gap-2">
                  <Filter className="w-3.5 h-3.5" style={{ color: t.textMuted }} />
                  <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value as 'all' | 'pending' | 'done')} className="rounded-md px-2.5 py-1.5 text-xs border" style={{ background: t.surface, borderColor: t.border, color: t.text }}>
                    <option value="all">Todos los estados</option><option value="pending">Pendientes</option><option value="done">Completadas</option>
                  </select>
                  <select value={filterType} onChange={(e) => setFilterType(e.target.value as 'all' | TaskType)} className="rounded-md px-2.5 py-1.5 text-xs border" style={{ background: t.surface, borderColor: t.border, color: t.text }}>
                    <option value="all">Todos los tipos</option><option value="Estudio">Estudio</option><option value="Personal">Personal</option><option value="Trabajo">Trabajo</option>
                  </select>
                </div>
              </div>

              {filteredTasks.length === 0 ? (
                <div className="text-center py-10 rounded-md border border-dashed" style={{ borderColor: t.border }}><p className="text-sm" style={{ color: t.textMuted }}>No hay tareas que coincidan con el filtro.</p></div>
              ) : (
                <ul className="space-y-2">
                  {filteredTasks.map((tk) => (
                    <li key={tk.id} className="p-3.5 rounded-md border flex items-start gap-3" style={{ background: t.bg, borderColor: t.border, opacity: tk.done ? 0.6 : 1 }}>
                      <input type="checkbox" checked={tk.done} onChange={() => handleToggleTaskDone(tk)} className="w-4 h-4 mt-1 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className={`text-sm font-semibold break-words ${tk.done ? 'line-through' : ''}`} style={{ color: tk.done ? t.textMuted : t.text }}>{tk.title}</div>
                        <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                          <PriorityBadge priority={tk.priority} t={t} />
                          <span className="px-2 py-0.5 rounded text-xs border" style={{ borderColor: t.border, color: t.textMuted }}>{tk.type}</span>
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs border" style={{ borderColor: t.border, color: t.textMuted }}><Clock className="w-3 h-3" />{tk.minutes} min</span>
                          {tk.deadline && <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs border" style={{ borderColor: t.border, color: t.textMuted }}><Calendar className="w-3 h-3" />{tk.deadline}</span>}
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs border" style={{ borderColor: t.border, color: t.textMuted }}><BatteryCharging className="w-3 h-3" />{tk.energy}</span>
                          {(tk.tags || []).map((tag) => (
                            <span key={tag} className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded text-xs" style={{ background: t.accentSoft, color: t.accent }}><Hash className="w-2.5 h-2.5" />{tag}</span>
                          ))}
                        </div>
                        {tk.notes && <p className="text-xs mt-2 px-2.5 py-1.5 rounded border" style={{ color: t.textMuted, borderColor: t.border }}>{tk.notes}</p>}
                      </div>
                      <div className="aulanexo-task-actions flex items-center gap-1.5 shrink-0">
                        <button aria-label={`Editar ${tk.title}`} onClick={() => handleStartEditTask(tk)} className="p-2 rounded-md border" style={{ borderColor: t.border, color: t.text }}><Edit3 className="w-3.5 h-3.5" /></button>
                        <button aria-label={`Eliminar ${tk.title}`} onClick={() => handleDeleteTask(tk.id)} className="p-2 rounded-md border" style={{ borderColor: t.danger, color: t.danger }}><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {/* ============ PLAN ============ */}
          {activeTab === 'plan' && (
            <div className="rounded-xl border p-4 sm:p-5 space-y-4" style={{ background: t.surface, borderColor: t.border }}>
              <div><h2 className="text-base font-bold">Plan automático (planificación inversa)</h2><p className="text-xs mt-0.5" style={{ color: t.textMuted }}>Distribuye los bloques desde la fecha límite hacia hoy ({settings.hoursPerDay} h/día máx.).</p></div>
              {planResult.isOverloaded ? (
                <div className="p-3.5 rounded-md border text-xs sm:text-sm" style={{ background: t.dangerSoft, borderColor: t.danger, color: t.danger }}><strong>Sobrecarga semanal:</strong> {planResult.required7} / {planResult.available7} min.</div>
              ) : (
                <div className="p-3.5 rounded-md border text-xs sm:text-sm" style={{ background: t.accentSoft, borderColor: t.accent, color: t.accent }}>Capacidad suficiente ({planResult.required7} / {planResult.available7} min).</div>
              )}
              {planResult.risk.length > 0 && (
                <div className="p-3.5 rounded-md border text-xs sm:text-sm" style={{ background: t.warnSoft, borderColor: t.warn, color: t.warn }}>
                  <div className="font-semibold flex items-center gap-2 mb-1.5"><ShieldAlert className="w-4 h-4" />Tareas en riesgo ({planResult.risk.length}):</div>
                  <ul className="list-disc pl-5 space-y-1">{planResult.risk.map((item) => <li key={item.task.id}><strong>{item.task.title}</strong> — {item.reason}</li>)}</ul>
                </div>
              )}
              {Object.keys(planResult.plan).length === 0 ? (
                <div className="text-center py-8 rounded-md border border-dashed" style={{ borderColor: t.border }}><p className="text-sm" style={{ color: t.textMuted }}>No hay bloques futuros planificados.</p></div>
              ) : (
                <div className="space-y-3">
                  {Object.keys(planResult.plan).sort().map((ds) => {
                    const blocks = planResult.plan[ds];
                    const totalMin = blocks.reduce((s, b) => s + b.minutes, 0);
                    return (
                      <div key={ds} className="rounded-md border p-3.5" style={{ borderColor: t.border }}>
                        <div className="flex items-center justify-between pb-2 mb-2 border-b" style={{ borderColor: t.border }}>
                          <h3 className="text-sm font-bold" style={{ color: t.accent }}>{humanDate(ds)} <span className="text-xs font-normal" style={{ color: t.textMuted }}>({ds})</span></h3>
                          <span className="text-xs font-medium px-2.5 py-0.5 rounded border" style={{ borderColor: t.border, color: t.textMuted }}>{totalMin} / {Math.round(settings.hoursPerDay * 60)} min</span>
                        </div>
                        <div className="divide-y" style={{ borderColor: t.border }}>
                          {blocks.map((b, idx) => (
                            <div key={`${b.taskId}-${idx}`} className="py-2 flex flex-wrap items-center justify-between gap-2 text-xs sm:text-sm">
                              <div className="flex items-center gap-2"><span className="font-bold">{b.minutes} min</span><span style={{ color: t.textMuted }}>·</span><span>{b.title}</span></div>
                              <div className="flex items-center gap-2"><span className="text-xs" style={{ color: t.textMuted }}>Límite {b.deadline}</span><PriorityBadge priority={b.priority} t={t} /></div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ============ NOTAS (estilo Notion) ============ */}
          {activeTab === 'notas' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
              <div className="lg:col-span-4 rounded-xl border p-3.5 space-y-2" style={{ background: t.surface, borderColor: t.border }}>
                <div className="flex gap-2">
                  <input value={newPageTitle} onChange={(e) => setNewPageTitle(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleCreatePage()} placeholder="Nueva página…" className="flex-1 rounded-md px-3 py-2 text-sm border" style={{ background: t.bg, borderColor: t.border, color: t.text }} />
                  <button onClick={handleCreatePage} className="px-3 rounded-md" style={{ background: t.accent, color: '#fff' }}><Plus className="w-4 h-4" /></button>
                </div>
                <div className="space-y-0.5 max-h-[500px] overflow-y-auto">
                  {pages.length === 0 && <p className="text-xs py-4 text-center" style={{ color: t.textMuted }}>Aún no tienes notas.</p>}
                  {pages.map((p) => (
                    <button key={p.id} onClick={() => setSelectedPageId(p.id)} className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md text-sm text-left" style={{ background: selectedPageId === p.id ? t.accentSoft : 'transparent', color: t.text }}>
                      <span>{p.icon}</span><span className="flex-1 truncate">{p.title}</span>
                      {p.favorite && <Star className="w-3 h-3 shrink-0" style={{ color: t.warn, fill: t.warn }} />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="lg:col-span-8 rounded-xl border p-4 sm:p-5" style={{ background: t.surface, borderColor: t.border, minHeight: 420 }}>
                {!selectedPage ? (
                  <div className="h-full flex items-center justify-center py-16"><p className="text-sm" style={{ color: t.textMuted }}>Selecciona o crea una nota a la izquierda.</p></div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <input value={selectedPage.title} onChange={(e) => handleUpdatePage({ ...selectedPage, title: e.target.value })}
                        className="text-xl font-bold bg-transparent outline-none flex-1" style={{ color: t.text }} />
                      <div className="flex items-center gap-1.5">
                        <button onClick={() => handleUpdatePage({ ...selectedPage, favorite: !selectedPage.favorite })} className="p-1.5 rounded-md border" style={{ borderColor: t.border }}>
                          <Star className="w-4 h-4" style={{ color: selectedPage.favorite ? t.warn : t.textMuted, fill: selectedPage.favorite ? t.warn : 'none' }} />
                        </button>
                        <button onClick={() => handleDeletePage(selectedPage.id)} className="p-1.5 rounded-md border" style={{ borderColor: t.danger, color: t.danger }}><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      {selectedPage.blocks.map((b) => (
                        <div key={b.id} className="flex items-start gap-2 group">
                          {b.type === 'todo' && <input type="checkbox" checked={!!b.checked} onChange={() => handleUpdatePage({ ...selectedPage, blocks: selectedPage.blocks.map((x) => x.id === b.id ? { ...x, checked: !x.checked } : x) })} className="mt-2.5" />}
                          {b.type === 'bullet' && <span className="mt-2.5" style={{ color: t.textMuted }}>•</span>}
                          <textarea value={b.content} onChange={(e) => handleUpdatePage({ ...selectedPage, blocks: selectedPage.blocks.map((x) => x.id === b.id ? { ...x, content: e.target.value } : x) })}
                            placeholder={b.type === 'heading' ? 'Encabezado' : 'Escribe algo…'} rows={1}
                            className="flex-1 bg-transparent outline-none resize-none py-1.5"
                            style={{ color: t.text, fontWeight: b.type === 'heading' ? 700 : 400, fontSize: b.type === 'heading' ? '1.05rem' : '0.9rem', textDecoration: b.checked ? 'line-through' : 'none' }} />
                          <button onClick={() => handleUpdatePage({ ...selectedPage, blocks: selectedPage.blocks.filter((x) => x.id !== b.id) })} className="opacity-0 group-hover:opacity-100 p-1 mt-1" style={{ color: t.textMuted }}><X className="w-3.5 h-3.5" /></button>
                        </div>
                      ))}
                    </div>
                    <div className="flex flex-wrap gap-1.5 pt-2 border-t" style={{ borderColor: t.border }}>
                      {(['text', 'heading', 'todo', 'bullet'] as const).map((bt) => (
                        <button key={bt} onClick={() => handleUpdatePage({ ...selectedPage, blocks: [...selectedPage.blocks, { id: uid(), type: bt, content: '' }] })}
                          className="text-xs px-2.5 py-1 rounded-md border" style={{ borderColor: t.border, color: t.textMuted }}>
                          + {bt === 'text' ? 'Texto' : bt === 'heading' ? 'Encabezado' : bt === 'todo' ? 'Pendiente' : 'Viñeta'}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ============ HÁBITOS ============ */}
          {activeTab === 'habitos' && (
            <div className="rounded-xl border p-4 sm:p-5 space-y-4" style={{ background: t.surface, borderColor: t.border }}>
              <div className="flex items-center justify-between"><h2 className="text-base font-bold flex items-center gap-2"><Flame className="w-4 h-4" style={{ color: t.accent }} />Hábitos (últimos 14 días)</h2></div>
              <div className="flex gap-2">
                <input value={newHabitName} onChange={(e) => setNewHabitName(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleCreateHabit()} placeholder="Nuevo hábito, ej: Leer 20 min" className="flex-1 rounded-md px-3 py-2 text-sm border" style={{ background: t.bg, borderColor: t.border, color: t.text }} />
                <button onClick={handleCreateHabit} className="px-3 rounded-md" style={{ background: t.accent, color: '#fff' }}><Plus className="w-4 h-4" /></button>
              </div>
              {habits.length === 0 ? (
                <div className="text-center py-10 rounded-md border border-dashed" style={{ borderColor: t.border }}><p className="text-sm" style={{ color: t.textMuted }}>Aún no registras hábitos.</p></div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border-separate" style={{ borderSpacing: '4px' }}>
                    <thead><tr><th className="text-left pr-3 sticky left-0" style={{ background: t.surface }}></th>{last14Days().map((d) => <th key={d} className="font-normal" style={{ color: t.textMuted }}>{parseDate(d).getDate()}</th>)}</tr></thead>
                    <tbody>
                      {habits.map((h) => (
                        <tr key={h.id}>
                          <td className="pr-3 whitespace-nowrap sticky left-0" style={{ background: t.surface }}>
                            <span className="inline-flex items-center gap-1.5 text-sm"><span className="w-2 h-2 rounded-full" style={{ background: h.color }} />{h.name}
                              <button onClick={() => handleDeleteHabit(h.id)} className="ml-1" style={{ color: t.textMuted }}><X className="w-3 h-3" /></button>
                            </span>
                          </td>
                          {last14Days().map((d) => (
                            <td key={d}>
                              <button onClick={() => toggleHabitDay(h, d)} className="w-6 h-6 rounded" style={{ background: h.checks[d] ? h.color : t.border }} />
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* ============ REVISIÓN SEMANAL ============ */}
          {activeTab === 'revision' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
              <div className="lg:col-span-6 rounded-xl border p-4 sm:p-5" style={{ background: t.surface, borderColor: t.border }}>
                <h2 className="text-base font-bold mb-3 flex items-center gap-2"><BookOpenCheck className="w-4 h-4" style={{ color: t.accent }} />Revisión semanal guiada</h2>
                <form onSubmit={handleSaveReview} className="space-y-3">
                  <div><label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>1. ¿Qué avanzaste esta semana? *</label><textarea required rows={2} value={revAvance} onChange={(e) => setRevAvance(e.target.value)} className="w-full rounded-md px-3 py-2 text-sm border" style={{ background: t.bg, borderColor: t.border, color: t.text }} /></div>
                  <div><label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>2. ¿Qué se atrasó y por qué?</label><textarea rows={2} value={revAtraso} onChange={(e) => setRevAtraso(e.target.value)} className="w-full rounded-md px-3 py-2 text-sm border" style={{ background: t.bg, borderColor: t.border, color: t.text }} /></div>
                  <div><label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>3. ¿Qué vas a eliminar, delegar o simplificar?</label><textarea rows={2} value={revEliminar} onChange={(e) => setRevEliminar(e.target.value)} className="w-full rounded-md px-3 py-2 text-sm border" style={{ background: t.bg, borderColor: t.border, color: t.text }} /></div>
                  <div><label className="block text-xs font-medium mb-1" style={{ color: t.textMuted }}>4. Tus 3 prioridades para la próxima semana *</label><textarea required rows={2} value={revPrioridades} onChange={(e) => setRevPrioridades(e.target.value)} className="w-full rounded-md px-3 py-2 text-sm border" style={{ background: t.bg, borderColor: t.border, color: t.text }} /></div>
                  <button type="submit" className="w-full font-semibold text-sm py-2.5 rounded-md" style={{ background: t.accent, color: '#fff' }}>Guardar revisión semanal</button>
                </form>
              </div>
              <div className="lg:col-span-6 rounded-xl border p-4 sm:p-5" style={{ background: t.surface, borderColor: t.border }}>
                <h3 className="text-base font-bold mb-3">Historial ({reviews.length})</h3>
                {reviews.length === 0 ? <div className="text-center py-10 rounded-md border border-dashed" style={{ borderColor: t.border }}><p className="text-sm" style={{ color: t.textMuted }}>Aún no hay revisiones.</p></div> : (
                  <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                    {[...reviews].reverse().map((r) => (
                      <div key={r.id} className="p-3.5 rounded-md border space-y-1.5 text-xs sm:text-sm" style={{ borderColor: t.border }}>
                        <span className="font-bold" style={{ color: t.accent }}>{r.date}</span>
                        <p><span style={{ color: t.textMuted }}>Avance:</span> {r.avance}</p>
                        {r.atraso && <p><span style={{ color: t.textMuted }}>Atraso:</span> {r.atraso}</p>}
                        <p className="p-2 rounded" style={{ background: t.accentSoft, color: t.accent }}><strong>Prioridades:</strong> {r.prioridades}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ============ ENFOQUE ============ */}
          {activeTab === 'enfoque' && (
            <div className="max-w-xl mx-auto space-y-4">
              <div className="rounded-xl border p-5 space-y-5" style={{ background: t.surface, borderColor: t.border }}>
                <div className="flex items-center justify-between">
                  <h2 className="text-base font-bold flex items-center gap-2"><Timer className="w-4 h-4" style={{ color: t.accent }} />Modo enfoque</h2>
                  <div className="flex gap-1.5">
                    {[15, 25, 45].map((preset) => (
                      <button key={preset} onClick={() => { setTimerRunning(false); setTimerFinishedBanner(false); setPomodoroMinutes(preset); setSecondsLeft(preset * 60); }}
                        className="px-2.5 py-1 rounded-md text-xs font-medium border" style={{ background: pomodoroMinutes === preset ? t.accentSoft : 'transparent', borderColor: pomodoroMinutes === preset ? t.accent : t.border, color: pomodoroMinutes === preset ? t.accent : t.textMuted }}>{preset}m</button>
                    ))}
                  </div>
                </div>

                {timerFinishedBanner && (
                  <div className="p-3.5 rounded-md border text-sm flex items-center justify-between" style={{ background: t.accentSoft, borderColor: t.accent, color: t.accent }}>
                    <span className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5" />¡Bloque completado! {interruptions > 0 ? `(${interruptions} interrupciones registradas)` : '(sin interrupciones)'}</span>
                    <button onClick={() => setTimerFinishedBanner(false)} className="text-xs underline">Cerrar</button>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-medium mb-1.5" style={{ color: t.textMuted }}>Tarea activa</label>
                  <select value={focusTaskId} onChange={(e) => setFocusTaskId(e.target.value)} className="w-full rounded-md px-3.5 py-2.5 text-sm border" style={{ background: t.bg, borderColor: t.border, color: t.text }}>
                    {tasks.filter((tk) => !tk.done).length === 0 ? <option value="">Sin tareas pendientes</option> : tasks.filter((tk) => !tk.done).map((tk) => <option key={tk.id} value={tk.id}>{tk.title} ({tk.minutes} min)</option>)}
                  </select>
                </div>

                <div className="py-6 rounded-xl border text-center" style={{ borderColor: t.border }}>
                  <div className="text-5xl sm:text-6xl font-black tracking-widest font-mono">{formattedTimer}</div>
                  <p className="text-xs mt-2" style={{ color: t.textMuted }}>{timerRunning ? `Sesión en curso${interruptions > 0 ? ` · ${interruptions} interrupción(es)` : ''}` : 'Listo para iniciar'}</p>
                </div>

                <div className="grid grid-cols-3 gap-2.5">
                  <button onClick={() => { setTimerFinishedBanner(false); setTimerRunning(true); }} disabled={timerRunning} className="inline-flex items-center justify-center gap-1.5 font-bold text-sm py-3 rounded-md disabled:opacity-40" style={{ background: t.accent, color: '#fff' }}><Play className="w-4 h-4" />Iniciar</button>
                  <button onClick={() => setTimerRunning(false)} disabled={!timerRunning} className="inline-flex items-center justify-center gap-1.5 font-medium text-sm py-3 rounded-md border disabled:opacity-40" style={{ borderColor: t.border, color: t.text }}><Pause className="w-4 h-4" />Pausar</button>
                  <button onClick={() => { setTimerRunning(false); setTimerFinishedBanner(false); setSecondsLeft(pomodoroMinutes * 60); setInterruptions(0); }} className="inline-flex items-center justify-center gap-1.5 font-medium text-sm py-3 rounded-md border" style={{ borderColor: t.border, color: t.text }}><RotateCcw className="w-4 h-4" />Reiniciar</button>
                </div>
              </div>

              <div className="rounded-xl border p-4 sm:p-5 space-y-3" style={{ background: t.surface, borderColor: t.border }}>
                <h3 className="text-sm font-bold flex items-center gap-2"><EyeOff className="w-4 h-4" style={{ color: t.warn }} />Lista de compromiso</h3>
                <p className="text-xs" style={{ color: t.textMuted }}>
                  Una página web no puede bloquear otras apps ni sitios de tu dispositivo — eso requiere permisos del sistema operativo (p. ej. Tiempo de Uso en iOS/Android, o una extensión de navegador como Freedom o Cold Turkey). Lo que sí hace esta lista: nombrar tus distracciones habituales como compromiso explícito antes de empezar, y esta app registra automáticamente cuántas veces cambiaste de pestaña mientras el temporizador corría, para que tengas datos reales de tu enfoque.
                </p>
                <div className="flex gap-2">
                  <input value={newBlockItem} onChange={(e) => setNewBlockItem(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleAddBlockItem()} placeholder="Ej: Instagram, correo, noticias…" className="flex-1 rounded-md px-3 py-2 text-sm border" style={{ background: t.bg, borderColor: t.border, color: t.text }} />
                  <button onClick={handleAddBlockItem} className="px-3 rounded-md" style={{ background: t.warn, color: '#fff' }}><Plus className="w-4 h-4" /></button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {blocklist.map((b) => (
                    <span key={b.id} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs" style={{ background: t.warnSoft, color: t.warn }}>
                      {b.name}<button onClick={() => handleRemoveBlockItem(b.id)}><X className="w-3 h-3" /></button>
                    </span>
                  ))}
                  {blocklist.length === 0 && <span className="text-xs" style={{ color: t.textMuted }}>Aún no añades compromisos.</span>}
                </div>
              </div>

              {focusSessions.length > 0 && (
                <div className="rounded-xl border p-4 sm:p-5" style={{ background: t.surface, borderColor: t.border }}>
                  <h3 className="text-sm font-bold mb-2">Historial de sesiones</h3>
                  <div className="space-y-1.5 max-h-56 overflow-y-auto">
                    {[...focusSessions].reverse().slice(0, 10).map((s) => (
                      <div key={s.id} className="flex items-center justify-between text-xs py-1.5 border-b" style={{ borderColor: t.border }}>
                        <span>{s.date} · {s.taskTitle}</span>
                        <span style={{ color: s.interruptions > 0 ? t.warn : t.accent }}>{s.plannedMinutes} min · {s.interruptions} interrup.</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ============ AJUSTES ============ */}
          {activeTab === 'ajustes' && (
            <div className="max-w-2xl mx-auto space-y-4">
              <div className="rounded-xl border p-4 sm:p-5 space-y-3" style={{ background: t.surface, borderColor: t.border }}>
                <h2 className="text-base font-bold">Capacidad de planificación</h2>
                <div className="flex gap-2">
                  <input type="number" min={0.5} max={16} step={0.5} value={hoursInput} onChange={(e) => setHoursInput(Number(e.target.value))} className="flex-1 rounded-md px-3.5 py-2.5 text-sm border" style={{ background: t.bg, borderColor: t.border, color: t.text }} />
                  <button onClick={() => handleSaveSettings({ hoursPerDay: Math.max(0.5, Number(hoursInput) || 3) }).then(() => showToast('Capacidad actualizada.'))} className="font-bold text-sm px-5 py-2.5 rounded-md" style={{ background: t.accent, color: '#fff' }}>Guardar</button>
                </div>
              </div>

              <div className="rounded-xl border p-4 sm:p-5 space-y-3" style={{ background: t.surface, borderColor: t.border }}>
                <h2 className="text-base font-bold">Inteligencia artificial</h2>
                <label className="flex items-center justify-between text-sm">
                  <span>Usar IA en la nube para descomponer tareas <span className="block text-xs mt-0.5" style={{ color: t.textMuted }}>Si lo activas, solo se envía el título de la tarea (nunca notas ni fecha) a una función servidor que lo redacta antes de llamar al modelo. Ver ARCHITECTURE.md.</span></span>
                  <input type="checkbox" checked={settings.aiDecompositionEnabled} onChange={(e) => handleSaveSettings({ aiDecompositionEnabled: e.target.checked })} className="w-5 h-5 shrink-0 ml-3" />
                </label>
              </div>

              <div className="rounded-xl border p-4 sm:p-5 space-y-3" style={{ background: t.surface, borderColor: t.border }}>
                <h2 className="text-base font-bold">Respaldo y portabilidad</h2>
                <p className="text-xs" style={{ color: t.textMuted }}>Tus datos viven en IndexedDB de este navegador. Exporta un JSON para respaldar o migrar.</p>
                <div className="flex flex-wrap gap-2.5">
                  <button onClick={handleExportJSON} className="inline-flex items-center gap-2 border text-xs sm:text-sm font-medium px-4 py-2.5 rounded-md" style={{ borderColor: t.border, color: t.text }}><Download className="w-4 h-4" style={{ color: t.accent }} />Exportar</button>
                  <button onClick={() => fileInputRef.current?.click()} className="inline-flex items-center gap-2 border text-xs sm:text-sm font-medium px-4 py-2.5 rounded-md" style={{ borderColor: t.border, color: t.text }}><Upload className="w-4 h-4" style={{ color: t.accent }} />Importar</button>
                  <input ref={fileInputRef} type="file" accept="application/json,.json" onChange={handleImportJSON} className="hidden" />
                </div>
              </div>

              <div className="rounded-xl border p-4 sm:p-5 space-y-3" style={{ background: t.surface, borderColor: t.border }}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div><h2 className="text-base font-bold flex items-center gap-2"><FlaskConical className="w-4 h-4" style={{ color: t.accent }} />Diagnóstico / Tests del motor</h2></div>
                  <button onClick={() => setTestResults(runPlannerUnitTests())} className="text-xs font-semibold px-3.5 py-2 rounded-md border" style={{ borderColor: t.accent, color: t.accent }}>Ejecutar tests</button>
                </div>
                {testResults && (
                  <div className="space-y-2 pt-2">
                    {testResults.map((tr) => (
                      <div key={tr.name} className="p-3 rounded-md border text-xs" style={{ background: tr.passed ? t.accentSoft : t.dangerSoft, borderColor: tr.passed ? t.accent : t.danger, color: tr.passed ? t.accent : t.danger }}>
                        <div className="font-bold flex items-center gap-1.5">{tr.passed ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}{tr.name}</div>
                        <p className="mt-1 opacity-90">{tr.details}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="rounded-xl border p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3" style={{ borderColor: t.danger }}>
                <div><h3 className="text-sm font-bold" style={{ color: t.danger }}>Reiniciar base de datos local</h3><p className="text-xs" style={{ color: t.textMuted }}>Elimina permanentemente todo lo guardado.</p></div>
                <button onClick={() => setConfirmClearModal(true)} className="text-xs font-semibold px-4 py-2.5 rounded-md border" style={{ borderColor: t.danger, color: t.danger }}>Borrar todos los datos</button>
              </div>
            </div>
          )}
        </main>

        {mobileMoreOpen && (
          <div className="aulanexo-more-panel" role="menu" aria-label="Más secciones">
            {navItems.filter((item) => !mobilePrimaryIds.includes(item.id)).map((item) => (
              <button key={item.id} onClick={() => { setActiveTab(item.id); setMobileMoreOpen(false); }}
                role="menuitem" style={{ background: activeTab === item.id ? t.accentSoft : 'transparent', color: activeTab === item.id ? t.accent : t.text }}>
                {item.icon}<span>{item.label}</span>
              </button>
            ))}
          </div>
        )}
        <nav className="aulanexo-mobile-nav" aria-label="Navegación principal">
          {navItems.filter((item) => mobilePrimaryIds.includes(item.id)).map((item) => (
            <button key={item.id} onClick={() => { setActiveTab(item.id); setMobileMoreOpen(false); }} className={activeTab === item.id ? 'active' : ''} aria-current={activeTab === item.id ? 'page' : undefined}>
              {item.icon}<span>{item.id === 'enfoque' ? 'Enfoque' : item.label.replace(/ \(.*\)/, '')}</span>
            </button>
          ))}
          <button onClick={() => setMobileMoreOpen((open) => !open)} className={mobileMoreOpen || !mobilePrimaryIds.includes(activeTab) ? 'active' : ''} aria-expanded={mobileMoreOpen}>
            <MoreHorizontal /><span>Más</span>
          </button>
        </nav>
      </div>

      {confirmClearModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.5)' }}>
          <div className="rounded-xl max-w-md w-full p-5 space-y-4 border" style={{ background: t.surface, borderColor: t.border }}>
            <div className="flex items-center gap-2.5" style={{ color: t.danger }}><AlertTriangle className="w-5 h-5" /><h3 className="text-base font-bold">¿Borrar todos los datos?</h3></div>
            <p className="text-sm" style={{ color: t.text }}>Esta acción eliminará tareas, notas, hábitos, sesiones y configuración. Te recomendamos exportar un respaldo antes.</p>
            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => setConfirmClearModal(false)} className="px-4 py-2 rounded-md border text-xs sm:text-sm font-medium" style={{ borderColor: t.border, color: t.text }}>Cancelar</button>
              <button onClick={handleConfirmClearAll} className="px-4 py-2 rounded-md text-xs sm:text-sm font-bold" style={{ background: t.danger, color: '#fff' }}>Sí, borrar todo</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
