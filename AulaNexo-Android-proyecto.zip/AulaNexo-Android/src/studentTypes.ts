// Tipos mínimos de persistencia para los datos que ya guarda AulaNexo.
// Las pantallas de materias, exámenes y tarjetas podrán ampliarlos al integrarse.
export interface Subject { id: string; [key: string]: unknown }
export interface ScheduleBlock { id: string; [key: string]: unknown }
export interface GradeItem { id: string; [key: string]: unknown }
export interface Exam { id: string; [key: string]: unknown }
export interface FlashcardDeck { id: string; [key: string]: unknown }
export interface Flashcard { id: string; [key: string]: unknown }
