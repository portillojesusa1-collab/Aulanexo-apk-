@echo off
cd /d "%~dp0"
call npm install
if errorlevel 1 pause & exit /b 1
call npm run build
if errorlevel 1 pause & exit /b 1
call npx cap add android
if errorlevel 1 (echo Si Android ya existe, omite este paso y ejecuta npx cap sync android.)
call npx cap sync android
call npx cap open android
pause
